/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 8.0.25 : Database - defenceresourcesystem
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`defenceresourcesystem` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `defenceresourcesystem`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Userid` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Mobile` longtext,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`Id`,`Userid`,`Password`,`Email`,`Mobile`) values 
(1,'revanth','1234','revanth@gmail.com','7935174808');

/*Table structure for table `canteine` */

DROP TABLE IF EXISTS `canteine`;

CREATE TABLE `canteine` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `Contact` longtext,
  `Service` varchar(300) DEFAULT NULL,
  `timings` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `canteine` */

insert  into `canteine`(`Id`,`Name`,`Location`,`Address`,`Contact`,`Service`,`timings`) values 
(1,'My Place','hyderabad','kphb','7047147027','serve',NULL),
(2,'mefel','nizampet','mainroad','34533553535','serve',NULL),
(3,'paradise','lb nagar','h-no 2/68','75644757','all','24hours'),
(4,'pistha house','nizampet','h-no 2/25','34533553','serve','24hours');

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Fullname` varchar(100) DEFAULT NULL,
  `Mobile` longtext,
  `Address` varchar(200) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `hospital` varchar(400) DEFAULT NULL,
  `canteen` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `customer` */

insert  into `customer`(`Id`,`Fullname`,`Mobile`,`Address`,`Email`,`Password`,`hospital`,`canteen`) values 
(1,'Revanth KUMAR','7035417890','Nakrekal','revanth@gmail.com','Revanth123',NULL,NULL),
(2,'kumar','7845936233','kphb colony','kumar@gmail.com','kumar@123',NULL,NULL),
(3,'lucky','123456789','jntu','lucky@gmail.com','1234',NULL,NULL),
(6,'vinod','7935174808','kphb','vinod@gmail.com','1234','lucky clinic','My Place'),
(7,'sasi','7935174808','kavali','adada@gmail.com','1234','Apollo','My Place');

/*Table structure for table `doctor` */

DROP TABLE IF EXISTS `doctor`;

CREATE TABLE `doctor` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Qualification` varchar(200) DEFAULT NULL,
  `Specialisation` varchar(200) DEFAULT NULL,
  `Timings` varchar(100) DEFAULT NULL,
  `Fee` double DEFAULT NULL,
  `Hospitalname` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Mobile` longtext,
  `Description` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `doctor` */

insert  into `doctor`(`Id`,`Name`,`Qualification`,`Specialisation`,`Timings`,`Fee`,`Hospitalname`,`Email`,`Mobile`,`Description`) values 
(1,'Dr.K.Revanth','M.B.B.S','Courdializist','10 am - 10 pm',200,'Apollo','revanth@gmail.com','7035728540','hello'),
(2,'lucky','MBBS','all','24hours',1000,'lucky clinic','lucky@gmail.com','123456','good'),
(3,'vinod','MBBS','heart','24hours',1200,'remedy','adada@gmail.com','4242564','nothing'),
(4,'pavam','MBBS','leg','24hours',500,'lucky clinic','pavan@gmail.com','7935174809','good');

/*Table structure for table `fooditems` */

DROP TABLE IF EXISTS `fooditems`;

CREATE TABLE `fooditems` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Itemname` varchar(100) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Cost` double DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `fooditems` */

insert  into `fooditems`(`Id`,`Name`,`Itemname`,`Description`,`Cost`) values 
(1,'my friend circle','burger','tasty',50),
(2,'mefel','biryani','good',120),
(3,'My Place','cicken fry','nice',250);

/*Table structure for table `hospital` */

DROP TABLE IF EXISTS `hospital`;

CREATE TABLE `hospital` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Location` varchar(200) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `Contact` longtext,
  `Service` varchar(300) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `timings` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `hospital` */

insert  into `hospital`(`Id`,`Name`,`Location`,`Address`,`Contact`,`Service`,`website`,`timings`) values 
(1,'Apollo','Hyderabad','jntu','7035417890','hellooo','appolo.com','24hours'),
(2,'lucky clinic','kphb','h-no 2/25','12345678','all','www.luckyclinic.com','24hours2'),
(3,'remedy','lb nagar','h-no 2/68','75644757','all','abc.com','24hours'),
(5,'asda','asdascsc','dssdc','345454','fef','sdsv','12hours');

/*Table structure for table `subadmin` */

DROP TABLE IF EXISTS `subadmin`;

CREATE TABLE `subadmin` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Userid` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Mobile` longtext,
  `rtype` varchar(400) DEFAULT NULL,
  `rname` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `subadmin` */

insert  into `subadmin`(`Id`,`Userid`,`Password`,`Email`,`Mobile`,`rtype`,`rname`) values 
(2,'vinod','1234','vinod@gmail.com','7935174808','canteene','My Place'),
(4,'pavan','1234','pavan@gmail.com','7935174808','hospital','lucky clinic');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
